<?php 
	$site_path = dirname(__FILE__);
	echo $site_path;
?>